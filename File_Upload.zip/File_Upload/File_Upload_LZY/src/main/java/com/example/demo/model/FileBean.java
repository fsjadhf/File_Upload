package com.example.demo.model;

public class FileBean {
    private Integer id;
    private String filesize;
    private String filetype;
    private String filename;
    private String time;
    private String uuid;
    private String filedir;

    public FileBean() {
    }

    @Override
    public String toString() {
        return "FileBean{" +
                "id=" + id +
                ", filesize='" + filesize + '\'' +
                ", filetype='" + filetype + '\'' +
                ", filename='" + filename + '\'' +
                ", time='" + time + '\'' +
                ", uuid='" + uuid + '\'' +
                ", filedir='" + filedir + '\'' +
                '}';
    }

    public FileBean(Integer id, String filesize, String filetype, String filename, String time, String uuid, String filedir) {
        this.id = id;
        this.filesize = filesize;
        this.filetype = filetype;
        this.filename = filename;
        this.time = time;
        this.uuid = uuid;
        this.filedir = filedir;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFilesize() {
        return filesize;
    }

    public void setFilesize(String filesize) {
        this.filesize = filesize;
    }

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getFiledir() {
        return filedir;
    }

    public void setFiledir(String filedir) {
        this.filedir = filedir;
    }
}
