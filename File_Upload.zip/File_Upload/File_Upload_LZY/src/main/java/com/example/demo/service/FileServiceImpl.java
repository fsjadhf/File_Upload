package com.example.demo.service;

import com.example.demo.mapper.FileMapper;
import com.example.demo.model.FileBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FileServiceImpl implements FileService{

    @Autowired
    FileMapper fileMapper;
    @Override
    public List FindAll() {
        return fileMapper.FindAll();
    }

    @Override
    public FileBean FindByUuid(String uuid) {
        return fileMapper.FindByUuid(uuid);
    }

    @Override
    public int InsertFile(FileBean fileBean) {
        return fileMapper.InsertFile(fileBean);
    }
}
