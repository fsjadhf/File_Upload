package com.example.demo.service;

import com.example.demo.model.FileBean;

import java.util.List;

public interface FileService {
    List FindAll();
    FileBean FindByUuid(String uuid);
    int InsertFile(FileBean fileBean);
}
