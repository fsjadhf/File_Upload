package com.example.demo.service;

import com.example.demo.model.FileBean;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class FileServiceTest {

    @Autowired
    FileService fileService;
    @Test
    void sout(){
        System.out.println(fileService.FindAll());
    }
    @Test
    void insert(){
        FileBean fileBean=new FileBean(0,"9","1","1","1","1","1");
        fileService.InsertFile(fileBean);
    }
    @Test
    void search(){
        System.out.println(fileService.FindByUuid("eacaab05-6f3c-4618-9d3c-c2627c717352"));
    }
}