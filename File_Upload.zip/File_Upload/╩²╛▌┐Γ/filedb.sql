/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : filedb

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2021-11-29 14:29:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `fileinfo`
-- ----------------------------
DROP TABLE IF EXISTS `fileinfo`;
CREATE TABLE `fileinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filesize` text,
  `filetype` text,
  `filename` text,
  `time` text,
  `filedir` text,
  `uuid` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of fileinfo
-- ----------------------------
INSERT INTO `fileinfo` VALUES ('12', '48863', '.xls', '49ec695c-56e5-43c5-836d-0009c43872f8.xls', '20211129', 'http://127.0.0.1:8888/upload/20211129/49ec695c-56e5-43c5-836d-0009c43872f8.xls', '49ec695c-56e5-43c5-836d-0009c43872f8');
INSERT INTO `fileinfo` VALUES ('13', '336556', '.pdf', 'db26b4f3-f9bb-41c1-9bda-b1d01fa0b484.pdf', '20211129', 'http://127.0.0.1:8888/upload/20211129/db26b4f3-f9bb-41c1-9bda-b1d01fa0b484.pdf', 'db26b4f3-f9bb-41c1-9bda-b1d01fa0b484');
